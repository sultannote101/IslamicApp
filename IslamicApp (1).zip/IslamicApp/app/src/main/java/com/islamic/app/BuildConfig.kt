package com.islamic.app
object BuildConfig {
    const val WEATHER_API_KEY = "" // Add your key from openweathermap.org
}
