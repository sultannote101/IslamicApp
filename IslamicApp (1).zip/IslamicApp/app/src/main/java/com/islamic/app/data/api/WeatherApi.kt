package com.islamic.app.data.api

import com.google.gson.annotations.SerializedName
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET
import retrofit2.http.Query

// ====== Data Models ======

data class WeatherResponse(
    val name: String = "",
    val main: Main = Main(),
    val weather: List<WeatherDesc> = emptyList(),
    val wind: Wind = Wind(),
    val visibility: Int = 0,
    val clouds: Clouds = Clouds()
) {
    data class Main(
        val temp: Double = 0.0,
        @SerializedName("feels_like") val feelsLike: Double = 0.0,
        val humidity: Int = 0,
        @SerializedName("temp_min") val tempMin: Double = 0.0,
        @SerializedName("temp_max") val tempMax: Double = 0.0
    )
    data class WeatherDesc(val id: Int = 0, val main: String = "", val description: String = "", val icon: String = "")
    data class Wind(val speed: Double = 0.0, val deg: Int = 0)
    data class Clouds(val all: Int = 0)
}

data class ForecastResponse(
    val list: List<ForecastItem> = emptyList(),
    val city: City = City()
) {
    data class ForecastItem(
        @SerializedName("dt_txt") val dtTxt: String = "",
        val main: WeatherResponse.Main = WeatherResponse.Main(),
        val weather: List<WeatherResponse.WeatherDesc> = emptyList()
    )
    data class City(val name: String = "", val country: String = "")
}

data class WeatherUiState(
    val cityName: String = "جاري التحديد...",
    val temperature: Int = 0,
    val feelsLike: Int = 0,
    val condition: String = "",
    val conditionAr: String = "جاري التحميل...",
    val humidity: Int = 0,
    val windSpeed: Double = 0.0,
    val weatherIcon: String = "☀️",
    val forecast: List<ForecastDay> = emptyList(),
    val isLoading: Boolean = true,
    val error: String? = null
)

data class ForecastDay(
    val day: String,
    val minTemp: Int,
    val maxTemp: Int,
    val icon: String,
    val condition: String
)

// ====== API Interface ======

interface WeatherApi {
    @GET("weather")
    suspend fun getCurrentWeather(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric",
        @Query("lang") lang: String = "ar"
    ): Response<WeatherResponse>

    @GET("forecast")
    suspend fun getForecast(
        @Query("lat") lat: Double,
        @Query("lon") lon: Double,
        @Query("appid") apiKey: String,
        @Query("units") units: String = "metric",
        @Query("lang") lang: String = "ar",
        @Query("cnt") count: Int = 40
    ): Response<ForecastResponse>
}

// ====== Retrofit Client ======

object WeatherClient {
    private const val BASE_URL = "https://api.openweathermap.org/data/2.5/"

    val api: WeatherApi by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(WeatherApi::class.java)
    }

    fun weatherIcon(condition: String): String = when (condition.lowercase()) {
        "clear"        -> "☀️"
        "clouds"       -> "⛅"
        "rain"         -> "🌧️"
        "drizzle"      -> "🌦️"
        "thunderstorm" -> "⛈️"
        "snow"         -> "❄️"
        "mist", "fog", "haze" -> "🌫️"
        "sand", "dust" -> "🌪️"
        else           -> "🌤️"
    }

    fun conditionAr(condition: String): String = when (condition.lowercase()) {
        "clear"        -> "صافٍ"
        "clouds"       -> "غائم"
        "rain"         -> "ممطر"
        "drizzle"      -> "رذاذ"
        "thunderstorm" -> "عاصفة رعدية"
        "snow"         -> "ثلوج"
        "mist"         -> "ضباب خفيف"
        "fog"          -> "ضباب"
        "haze"         -> "ضبابية"
        "sand"         -> "عاصفة رملية"
        "dust"         -> "غبار"
        else           -> condition
    }
}
