package com.islamic.app.glance

import android.content.Context
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.*
import androidx.glance.action.actionStartActivity
import androidx.glance.action.clickable
import androidx.glance.appwidget.*
import androidx.glance.appwidget.lazy.LazyColumn
import androidx.glance.layout.*
import androidx.glance.text.*
import androidx.glance.unit.ColorProvider
import com.islamic.app.MainActivity
import com.islamic.app.domain.model.PrayerCalculator
import com.islamic.app.domain.model.UmmAlQuraCalendar
import java.util.Calendar

// ===========================
// 1. CALENDAR WIDGET
// ===========================

class CalendarWidget : GlanceAppWidget() {
    @Composable
    override fun Content() {
        val context = LocalContext.current
        val hijri = UmmAlQuraCalendar.today()
        val occasion = UmmAlQuraCalendar.getOccasion(hijri)

        GlanceTheme {
            Box(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(ColorProvider(Color(0xDD0D2137)))
                    .cornerRadius(20.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = GlanceModifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = UmmAlQuraCalendar.dayNamesAr[hijri.dayOfWeek],
                        style = TextStyle(
                            color = ColorProvider(Color(0xAAFFFFFF)),
                            fontSize = 11.sp
                        )
                    )
                    Spacer(GlanceModifier.height(4.dp))
                    Text(
                        text = UmmAlQuraCalendar.toArabic(hijri.day),
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = 52.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = UmmAlQuraCalendar.hijriMonthsAr[hijri.month - 1],
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFD4AF37)),
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Text(
                        text = "${UmmAlQuraCalendar.toArabic(hijri.year)} هـ",
                        style = TextStyle(
                            color = ColorProvider(Color(0xCCFFFFFF)),
                            fontSize = 12.sp
                        )
                    )
                    if (occasion != null) {
                        Spacer(GlanceModifier.height(6.dp))
                        Text(
                            text = occasion,
                            style = TextStyle(
                                color = ColorProvider(Color(0xFFFFD700)),
                                fontSize = 10.sp
                            ),
                            maxLines = 1
                        )
                    }
                }
            }
        }
    }
}

class CalendarWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget = CalendarWidget()
}

// ===========================
// 2. PRAYER TIMES WIDGET
// ===========================

class PrayerWidget : GlanceAppWidget() {
    @Composable
    override fun Content() {
        // Use Riyadh as default - in production, load from DataStore
        val prayers = try {
            PrayerCalculator.calculate(24.6877, 46.7219)
        } catch (e: Exception) { null }

        GlanceTheme {
            Box(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(ColorProvider(Color(0xDD0D1F1A)))
                    .cornerRadius(20.dp)
                    .clickable(actionStartActivity<MainActivity>())
            ) {
                Column(modifier = GlanceModifier.padding(16.dp)) {
                    Text(
                        "🕌 أوقات الصلاة",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFFD4AF37)),
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold
                        )
                    )
                    Spacer(GlanceModifier.height(10.dp))

                    if (prayers != null) {
                        PrayerWidgetRow("الفجر",   prayers.fajr,    prayers.nextPrayer == "الفجر")
                        PrayerWidgetRow("الظهر",   prayers.dhuhr,   prayers.nextPrayer == "الظهر")
                        PrayerWidgetRow("العصر",   prayers.asr,     prayers.nextPrayer == "العصر")
                        PrayerWidgetRow("المغرب",  prayers.maghrib, prayers.nextPrayer == "المغرب")
                        PrayerWidgetRow("العشاء",  prayers.isha,    prayers.nextPrayer == "العشاء")
                    } else {
                        Text("تعذّر تحميل الأوقات",
                            style = TextStyle(color = ColorProvider(Color.White), fontSize = 12.sp))
                    }
                }
            }
        }
    }
}

@Composable
private fun PrayerWidgetRow(name: String, time: String, isNext: Boolean) {
    Row(
        modifier = GlanceModifier.fillMaxWidth().padding(vertical = 4.dp),
        horizontalAlignment = Alignment.End
    ) {
        Spacer(GlanceModifier.defaultWeight())
        Text(
            text = time,
            style = TextStyle(
                color = ColorProvider(if (isNext) Color(0xFFD4AF37) else Color(0xAAFFFFFF)),
                fontSize = 13.sp,
                fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal
            )
        )
        Spacer(GlanceModifier.width(12.dp))
        Text(
            text = name,
            style = TextStyle(
                color = ColorProvider(if (isNext) Color.White else Color(0xAAFFFFFF)),
                fontSize = 13.sp,
                fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal
            )
        )
    }
}

class PrayerWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget = PrayerWidget()
}

// ===========================
// 3. WEATHER WIDGET
// ===========================

class WeatherWidget : GlanceAppWidget() {
    @Composable
    override fun Content() {
        // Weather data loaded from DataStore in production
        GlanceTheme {
            Box(
                modifier = GlanceModifier
                    .fillMaxSize()
                    .background(ColorProvider(Color(0xDD0D1B2E)))
                    .cornerRadius(20.dp)
                    .clickable(actionStartActivity<MainActivity>()),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    modifier = GlanceModifier.padding(16.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        "☀️",
                        style = TextStyle(fontSize = 40.sp)
                    )
                    Text(
                        "--°",
                        style = TextStyle(
                            color = ColorProvider(Color.White),
                            fontSize = 36.sp,
                            fontWeight = FontWeight.Thin
                        )
                    )
                    Text(
                        "افتح التطبيق للطقس",
                        style = TextStyle(
                            color = ColorProvider(Color(0xFF4FC3F7)),
                            fontSize = 11.sp
                        )
                    )
                }
            }
        }
    }
}

class WeatherWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget = WeatherWidget()
}
