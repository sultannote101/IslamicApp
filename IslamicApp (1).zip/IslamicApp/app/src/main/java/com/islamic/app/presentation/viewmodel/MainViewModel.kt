package com.islamic.app.presentation.viewmodel

import android.annotation.SuppressLint
import android.app.Application
import android.location.Location
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import com.google.android.gms.tasks.CancellationTokenSource
import com.islamic.app.BuildConfig
import com.islamic.app.data.api.ForecastDay
import com.islamic.app.data.api.WeatherClient
import com.islamic.app.data.api.WeatherUiState
import com.islamic.app.domain.model.PrayerCalculator
import com.islamic.app.domain.model.PrayerTimes
import com.islamic.app.domain.model.UmmAlQuraCalendar
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*

data class CalendarUiState(
    val hijriDay: String = "",
    val hijriMonth: String = "",
    val hijriYear: String = "",
    val dayName: String = "",
    val gregorianDate: String = "",
    val gregorianMonth: String = "",
    val occasion: String? = null,
    val isRamadan: Boolean = false,
    val isFriday: Boolean = false
)

data class PrayerUiState(
    val times: PrayerTimes? = null,
    val isLoading: Boolean = true,
    val locationName: String = "جاري التحديد..."
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val fusedLocation = LocationServices.getFusedLocationProviderClient(application)

    private val _calendarState = MutableStateFlow(CalendarUiState())
    val calendarState: StateFlow<CalendarUiState> = _calendarState.asStateFlow()

    private val _prayerState = MutableStateFlow(PrayerUiState())
    val prayerState: StateFlow<PrayerUiState> = _prayerState.asStateFlow()

    private val _weatherState = MutableStateFlow(WeatherUiState())
    val weatherState: StateFlow<WeatherUiState> = _weatherState.asStateFlow()

    // Replace with your real API key from openweathermap.org (free)
    private val apiKey = BuildConfig.WEATHER_API_KEY.takeIf { it.isNotBlank() }
        ?: "REPLACE_WITH_YOUR_KEY"

    init {
        loadCalendar()
    }

    private fun loadCalendar() {
        val h = UmmAlQuraCalendar.today()
        val cal = Calendar.getInstance()
        val gDay   = cal.get(Calendar.DAY_OF_MONTH)
        val gMonth = UmmAlQuraCalendar.gregorianMonthsAr[cal.get(Calendar.MONTH)]
        val gYear  = cal.get(Calendar.YEAR)

        _calendarState.value = CalendarUiState(
            hijriDay    = UmmAlQuraCalendar.toArabic(h.day),
            hijriMonth  = UmmAlQuraCalendar.hijriMonthsAr[h.month - 1],
            hijriYear   = "${UmmAlQuraCalendar.toArabic(h.year)} هـ",
            dayName     = UmmAlQuraCalendar.dayNamesAr[h.dayOfWeek],
            gregorianDate  = UmmAlQuraCalendar.toArabic(gDay),
            gregorianMonth = "$gMonth $gYear م",
            occasion    = UmmAlQuraCalendar.getOccasion(h),
            isRamadan   = UmmAlQuraCalendar.isRamadan(h),
            isFriday    = UmmAlQuraCalendar.isFriday(h)
        )
    }

    @SuppressLint("MissingPermission")
    fun loadLocationData() {
        viewModelScope.launch {
            try {
                val cts = CancellationTokenSource()
                val location = fusedLocation.getCurrentLocation(
                    Priority.PRIORITY_HIGH_ACCURACY, cts.token
                ).await()
                location?.let { processLocation(it) }
            } catch (e: Exception) {
                // Fallback: Riyadh coordinates
                processLocation(null)
            }
        }
    }

    private fun processLocation(location: Location?) {
        val lat = location?.latitude  ?: 24.6877
        val lng = location?.longitude ?: 46.7219

        // Calculate prayer times
        viewModelScope.launch {
            try {
                val prayers = PrayerCalculator.calculate(lat, lng)
                _prayerState.value = PrayerUiState(
                    times = prayers,
                    isLoading = false,
                    locationName = if (location != null) "موقعك الحالي" else "الرياض"
                )
            } catch (e: Exception) {
                _prayerState.value = PrayerUiState(isLoading = false)
            }
        }

        // Fetch weather
        viewModelScope.launch {
            try {
                val currentRes = WeatherClient.api.getCurrentWeather(lat, lng, apiKey)
                val forecastRes = WeatherClient.api.getForecast(lat, lng, apiKey)

                if (currentRes.isSuccessful && currentRes.body() != null) {
                    val w = currentRes.body()!!
                    val condition = w.weather.firstOrNull()?.main ?: ""
                    val forecast = buildForecast(forecastRes.body())

                    _weatherState.value = WeatherUiState(
                        cityName     = w.name.ifBlank { if (location != null) "موقعك" else "الرياض" },
                        temperature  = w.main.temp.toInt(),
                        feelsLike    = w.main.feelsLike.toInt(),
                        condition    = condition,
                        conditionAr  = w.weather.firstOrNull()?.description ?: WeatherClient.conditionAr(condition),
                        humidity     = w.main.humidity,
                        windSpeed    = w.wind.speed,
                        weatherIcon  = WeatherClient.weatherIcon(condition),
                        forecast     = forecast,
                        isLoading    = false
                    )
                } else {
                    _weatherState.value = WeatherUiState(
                        isLoading = false,
                        error = "تعذّر تحميل بيانات الطقس\nأضف مفتاح API"
                    )
                }
            } catch (e: Exception) {
                _weatherState.value = WeatherUiState(
                    isLoading = false,
                    error = "تحقق من اتصالك بالإنترنت"
                )
            }
        }
    }

    private fun buildForecast(forecastRes: com.islamic.app.data.api.ForecastResponse?): List<ForecastDay> {
        if (forecastRes == null) return emptyList()
        val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val dayFormat = SimpleDateFormat("EEEE", Locale("ar"))
        val grouped = forecastRes.list.groupBy { it.dtTxt.substring(0, 10) }
        return grouped.entries.take(5).map { (dateStr, items) ->
            val date = try { sdf.parse(dateStr) } catch (e: Exception) { Date() }
            val dayName = dayFormat.format(date ?: Date())
            val condition = items.firstOrNull()?.weather?.firstOrNull()?.main ?: ""
            ForecastDay(
                day       = dayName,
                minTemp   = items.minOf { it.main.temp }.toInt(),
                maxTemp   = items.maxOf { it.main.temp }.toInt(),
                icon      = WeatherClient.weatherIcon(condition),
                condition = WeatherClient.conditionAr(condition)
            )
        }
    }

    fun refresh() {
        loadCalendar()
        loadLocationData()
    }
}
