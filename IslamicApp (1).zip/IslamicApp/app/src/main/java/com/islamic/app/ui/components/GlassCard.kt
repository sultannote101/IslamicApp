package com.islamic.app.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.islamic.app.ui.theme.*

/**
 * GlassCard - Core Glassmorphic card component
 * Uses gradient background + translucent border + subtle glow
 */
@Composable
fun GlassCard(
    modifier: Modifier = Modifier,
    cornerRadius: Dp = 24.dp,
    glowColor: Color = IslamicGold,
    glowIntensity: Float = 0.15f,
    borderAlpha: Float = 0.3f,
    backgroundAlpha: Float = 0.12f,
    content: @Composable BoxScope.() -> Unit
) {
    val shape = RoundedCornerShape(cornerRadius)

    // Subtle breathing glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "glow")
    val glowPulse by infiniteTransition.animateFloat(
        initialValue = glowIntensity,
        targetValue = glowIntensity * 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(3000, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "glowPulse"
    )

    Box(
        modifier = modifier
            .clip(shape)
            .drawBehind {
                // Glow effect behind the card
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            glowColor.copy(alpha = glowPulse),
                            Color.Transparent
                        ),
                        radius = size.maxDimension * 0.8f,
                        center = Offset(size.width * 0.3f, size.height * 0.2f)
                    ),
                    radius = size.maxDimension * 0.8f,
                    center = Offset(size.width * 0.3f, size.height * 0.2f)
                )
            }
            .background(
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = backgroundAlpha + 0.05f),
                        Color.White.copy(alpha = backgroundAlpha),
                    ),
                    start = Offset(0f, 0f),
                    end = Offset(Float.POSITIVE_INFINITY, Float.POSITIVE_INFINITY)
                ),
                shape = shape
            )
            .border(
                width = 1.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color.White.copy(alpha = borderAlpha),
                        Color.White.copy(alpha = borderAlpha * 0.3f),
                        glowColor.copy(alpha = borderAlpha * 0.5f),
                    )
                ),
                shape = shape
            ),
        content = content
    )
}

/**
 * GlassCardGreen - Green tinted glass card for calendar
 */
@Composable
fun GlassCardGreen(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) = GlassCard(
    modifier = modifier,
    glowColor = IslamicGreenLight,
    glowIntensity = 0.12f,
    content = content
)

/**
 * GlassCardGold - Gold tinted glass card for prayer times
 */
@Composable
fun GlassCardGold(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) = GlassCard(
    modifier = modifier,
    glowColor = IslamicGold,
    glowIntensity = 0.18f,
    content = content
)

/**
 * GlassCardBlue - Blue tinted glass card for weather
 */
@Composable
fun GlassCardBlue(
    modifier: Modifier = Modifier,
    content: @Composable BoxScope.() -> Unit
) = GlassCard(
    modifier = modifier,
    glowColor = Color(0xFF4FC3F7),
    glowIntensity = 0.15f,
    content = content
)
