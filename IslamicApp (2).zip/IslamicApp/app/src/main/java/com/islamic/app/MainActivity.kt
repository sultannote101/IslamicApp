package com.islamic.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import com.google.accompanist.permissions.*
import com.islamic.app.presentation.viewmodel.MainViewModel
import com.islamic.app.ui.screens.*
import com.islamic.app.ui.theme.*

class MainActivity : ComponentActivity() {

    private val viewModel: MainViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        // Splash screen (Android 12+)
        installSplashScreen()
        super.onCreate(savedInstanceState)

        // Edge-to-edge (Android 16 default)
        enableEdgeToEdge()
        WindowCompat.setDecorFitsSystemWindows(window, false)

        setContent {
            IslamicAppTheme {
                IslamicAppContent(viewModel)
            }
        }
    }
}

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun IslamicAppContent(viewModel: MainViewModel) {
    val calendarState by viewModel.calendarState.collectAsState()
    val prayerState   by viewModel.prayerState.collectAsState()
    val weatherState  by viewModel.weatherState.collectAsState()

    // Location permission
    val locationPermission = rememberMultiplePermissionsState(
        listOf(
            android.Manifest.permission.ACCESS_FINE_LOCATION,
            android.Manifest.permission.ACCESS_COARSE_LOCATION
        )
    )

    LaunchedEffect(locationPermission.allPermissionsGranted) {
        if (locationPermission.allPermissionsGranted) {
            viewModel.loadLocationData()
        } else {
            locationPermission.launchMultiplePermissionRequest()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .drawBehind {
                // Animated starry background
                drawRect(
                    brush = Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF060D1A),
                            Color(0xFF0A1628),
                            Color(0xFF0D1F38),
                        )
                    )
                )
                // Green glow top-right
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x221B5E20), Color.Transparent),
                        radius = size.width * 0.6f,
                        center = Offset(size.width * 0.8f, size.height * 0.1f)
                    ),
                    radius = size.width * 0.6f,
                    center = Offset(size.width * 0.8f, size.height * 0.1f)
                )
                // Gold glow bottom-left
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0x22D4AF37), Color.Transparent),
                        radius = size.width * 0.5f,
                        center = Offset(size.width * 0.2f, size.height * 0.85f)
                    ),
                    radius = size.width * 0.5f,
                    center = Offset(size.width * 0.2f, size.height * 0.85f)
                )
            }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(top = 60.dp, bottom = 32.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // App header
            AppHeader()

            // Permission notice if needed
            if (!locationPermission.allPermissionsGranted) {
                PermissionBanner { locationPermission.launchMultiplePermissionRequest() }
            }

            // Calendar Card
            AnimatedVisibility(
                visible = true,
                enter = slideInVertically(
                    initialOffsetY = { -40 },
                    animationSpec = tween(500)
                ) + fadeIn(tween(500))
            ) {
                CalendarCard(state = calendarState)
            }

            // Prayer Times Card
            AnimatedVisibility(
                visible = true,
                enter = slideInVertically(
                    initialOffsetY = { -40 },
                    animationSpec = tween(600, delayMillis = 100)
                ) + fadeIn(tween(600, delayMillis = 100))
            ) {
                PrayerCard(state = prayerState)
            }

            // Weather Card
            AnimatedVisibility(
                visible = true,
                enter = slideInVertically(
                    initialOffsetY = { -40 },
                    animationSpec = tween(700, delayMillis = 200)
                ) + fadeIn(tween(700, delayMillis = 200))
            ) {
                WeatherCard(state = weatherState)
            }

            // Widgets hint card
            WidgetsHintCard()

            Spacer(Modifier.height(16.dp))
        }
    }
}

@Composable
private fun AppHeader() {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "بسم الله الرحمن الرحيم",
            color = Color.White.copy(alpha = 0.4f),
            fontSize = 12.sp,
            letterSpacing = 0.5.sp
        )
        Text(
            text = "🌙 الدليل الإسلامي",
            color = IslamicGold,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun PermissionBanner(onClick: () -> Unit) {
    Surface(
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        color = Color(0x33FF9800),
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "اضغط للسماح بالوصول للموقع\nلأوقات الصلاة والطقس الدقيقة",
                color = Color(0xFFFF9800),
                fontSize = 13.sp
            )
            Text("📍", fontSize = 24.sp)
        }
    }
}

@Composable
private fun WidgetsHintCard() {
    com.islamic.app.ui.components.GlassCard(
        modifier = Modifier.fillMaxWidth(),
        glowColor = IslamicGreenLight,
        backgroundAlpha = 0.06f
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.End
        ) {
            Text(
                "📱 الـ Widgets متاحة!",
                color = IslamicGold,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold
            )
            Spacer(Modifier.height(4.dp))
            Text(
                "اضغط مطولاً على الشاشة الرئيسية\nلإضافة: التقويم • أوقات الصلاة • الطقس",
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 12.sp,
                lineHeight = 20.sp
            )
        }
    }
}
