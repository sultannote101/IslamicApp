package com.islamic.app.domain.model

import java.util.Calendar

object UmmAlQuraCalendar {

    val hijriMonthsAr = arrayOf(
        "مُحرَّم", "صَفَر", "ربيع الأول", "ربيع الآخر",
        "جمادى الأولى", "جمادى الآخرة", "رجب", "شعبان",
        "رمضان", "شوال", "ذو القعدة", "ذو الحجة"
    )

    val dayNamesAr = arrayOf(
        "الأحد", "الاثنين", "الثلاثاء", "الأربعاء",
        "الخميس", "الجمعة", "السبت"
    )

    val gregorianMonthsAr = arrayOf(
        "يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو",
        "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"
    )

    private val arabicDigits = arrayOf("٠","١","٢","٣","٤","٥","٦","٧","٨","٩")

    data class HijriDate(
        val day: Int, val month: Int, val year: Int, val dayOfWeek: Int
    )

    fun toArabic(n: Int): String =
        n.toString().map { if (it.isDigit()) arabicDigits[it.digitToInt()] else it.toString() }.joinToString("")

    private fun gregorianToJdn(y: Int, m: Int, d: Int): Long {
        val a = (14 - m) / 12
        val yr = y + 4800 - a
        val mo = m + 12 * a - 3
        return d + (153 * mo + 2) / 5 + 365L * yr + yr / 4 - yr / 100 + yr / 400 - 32045
    }

    private fun hijriYearStart(year: Int): Long {
        val y = year - 1
        return y * 354L + (11 * y + 3) / 30 + 1948440L
    }

    private fun isLeapHijri(year: Int) = (11 * year + 14) % 30 < 11

    private fun monthLength(year: Int, month: Int): Int = when {
        month % 2 == 1 -> 30
        month == 12 && isLeapHijri(year) -> 30
        else -> 29
    }

    private fun monthStart(year: Int, month: Int): Long {
        var days = 0L
        for (m in 1 until month) days += monthLength(year, m)
        return hijriYearStart(year) + days
    }

    fun toHijri(gYear: Int, gMonth: Int, gDay: Int): HijriDate {
        val cal = Calendar.getInstance().apply { set(gYear, gMonth - 1, gDay) }
        val dow = cal.get(Calendar.DAY_OF_WEEK) - 1
        val jdn = gregorianToJdn(gYear, gMonth, gDay)
        val epoch = 1948440L
        if (jdn < epoch) return HijriDate(1, 1, 1, dow)

        var hYear = ((jdn - epoch) * 30 / 10631).toInt() + 1
        while (hijriYearStart(hYear + 1) <= jdn) hYear++
        while (hijriYearStart(hYear) > jdn) hYear--

        var hMonth = 1
        var hDay = 1
        for (m in 1..12) {
            val ms = monthStart(hYear, m)
            val next = if (m < 12) monthStart(hYear, m + 1) else hijriYearStart(hYear + 1)
            if (jdn < next) { hMonth = m; hDay = (jdn - ms + 1).toInt(); break }
        }
        return HijriDate(hDay, hMonth, hYear, dow)
    }

    fun today(): HijriDate {
        val c = Calendar.getInstance()
        return toHijri(c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
    }

    fun getOccasion(h: HijriDate): String? = when {
        h.day == 1  && h.month == 1  -> "رأس السنة الهجرية 🌙"
        h.day == 10 && h.month == 1  -> "يوم عاشوراء"
        h.day == 12 && h.month == 3  -> "المولد النبوي الشريف ﷺ"
        h.day == 27 && h.month == 7  -> "ليلة الإسراء والمعراج"
        h.day == 1  && h.month == 9  -> "بداية رمضان المبارك 🌙"
        h.day == 27 && h.month == 9  -> "ليلة القدر المباركة ✨"
        h.day == 1  && h.month == 10 -> "عيد الفطر المبارك 🎉"
        h.day == 9  && h.month == 12 -> "يوم عرفة المبارك"
        h.day == 10 && h.month == 12 -> "عيد الأضحى المبارك 🐑"
        else -> null
    }

    fun isRamadan(h: HijriDate) = h.month == 9
    fun isFriday(h: HijriDate) = h.dayOfWeek == 5
}
