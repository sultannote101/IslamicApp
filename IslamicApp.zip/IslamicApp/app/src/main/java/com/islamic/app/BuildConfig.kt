package com.islamic.app
object BuildConfig {
    const val WEATHER_API_KEY = "8d742aa7f81675ffab703527db707c28" // Add your key from openweathermap.org
}
