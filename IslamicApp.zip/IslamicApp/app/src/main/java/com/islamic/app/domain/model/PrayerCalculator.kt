package com.islamic.app.domain.model

import kotlin.math.*
import java.util.Calendar

data class PrayerTimes(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val nextPrayer: String = "",
    val nextPrayerTime: String = "",
    val minutesToNext: Int = 0
)

object PrayerCalculator {

    // Umm Al-Qura method parameters
    private const val FAJR_ANGLE = 18.5
    private const val ISHA_INTERVAL = 90.0 // minutes after maghrib

    fun calculate(lat: Double, lng: Double, date: Calendar = Calendar.getInstance()): PrayerTimes {
        val year = date.get(Calendar.YEAR)
        val month = date.get(Calendar.MONTH) + 1
        val day = date.get(Calendar.DAY_OF_MONTH)

        val jd = julianDay(year, month, day)
        val d = jd - 2451545.0

        // Sun position
        val g = Math.toRadians((357.529 + 0.98560028 * d) % 360)
        val q = (280.459 + 0.98564736 * d) % 360
        val l = Math.toRadians((q + 1.915 * sin(g) + 0.020 * sin(2 * g)) % 360)
        val e = Math.toRadians(23.439 - 0.00000036 * d)

        val ra = Math.toDegrees(atan2(cos(e) * sin(l), cos(l))) / 15.0
        val dec = asin(sin(e) * sin(l))

        // Equation of time
        val eqt = q / 15.0 - (ra % 24)

        // Transit (Dhuhr)
        val tz = date.timeZone.rawOffset / 3600000.0
        val transit = 12.0 + tz - lng / 15.0 - eqt

        // Sunrise/Sunset
        val latRad = Math.toRadians(lat)
        val cosH0 = (sin(Math.toRadians(-0.8333)) - sin(latRad) * sin(dec)) /
                    (cos(latRad) * cos(dec))
        val h0 = Math.toDegrees(acos(cosH0.coerceIn(-1.0, 1.0))) / 15.0

        val sunrise = transit - h0
        val sunset  = transit + h0

        // Fajr
        val cosHf = (sin(Math.toRadians(-FAJR_ANGLE)) - sin(latRad) * sin(dec)) /
                    (cos(latRad) * cos(dec))
        val hf = Math.toDegrees(acos(cosHf.coerceIn(-1.0, 1.0))) / 15.0
        val fajr = transit - hf

        // Asr (Shafi method - shadow = 1 + object length)
        val asrAngle = Math.toDegrees(atan(1.0 / (1.0 + tan(abs(lat - Math.toDegrees(dec))))))
        val cosHa = (sin(Math.toRadians(asrAngle)) - sin(latRad) * sin(dec)) /
                    (cos(latRad) * cos(dec))
        val ha = Math.toDegrees(acos(cosHa.coerceIn(-1.0, 1.0))) / 15.0
        val asr = transit + ha

        // Maghrib = Sunset
        val maghrib = sunset

        // Isha = Maghrib + 90 min (Umm Al-Qura)
        val isha = maghrib + (ISHA_INTERVAL / 60.0)

        val prayers = listOf(
            "الفجر"   to fajr,
            "الشروق"  to sunrise,
            "الظهر"   to transit,
            "العصر"   to asr,
            "المغرب"  to maghrib,
            "العشاء"  to isha
        )

        // Find next prayer
        val now = Calendar.getInstance()
        val currentHour = now.get(Calendar.HOUR_OF_DAY) + now.get(Calendar.MINUTE) / 60.0
        val next = prayers.firstOrNull { (name, time) -> name != "الشروق" && time > currentHour }
        val nextName = next?.first ?: "الفجر"
        val nextTime = next?.second ?: fajr + 24
        val minsToNext = ((nextTime - currentHour) * 60).toInt().coerceAtLeast(0)

        return PrayerTimes(
            fajr    = formatTime(fajr),
            sunrise = formatTime(sunrise),
            dhuhr   = formatTime(transit),
            asr     = formatTime(asr),
            maghrib = formatTime(maghrib),
            isha    = formatTime(isha),
            nextPrayer     = nextName,
            nextPrayerTime = formatTime(nextTime % 24),
            minutesToNext  = minsToNext
        )
    }

    private fun julianDay(y: Int, m: Int, d: Int): Double {
        val mm = if (m <= 2) { m + 12 } else m
        val yy = if (m <= 2) { y - 1 } else y
        val a = (yy / 100).toInt()
        val b = 2 - a + a / 4
        return (365.25 * (yy + 4716)).toInt() + (30.6001 * (mm + 1)).toInt() + d + b - 1524.5
    }

    private fun formatTime(t: Double): String {
        var time = t % 24
        if (time < 0) time += 24
        val h = time.toInt()
        val m = ((time - h) * 60).roundToInt()
        val hh = if (m == 60) h + 1 else h
        val mm = if (m == 60) 0 else m
        val ampm = if (hh % 24 < 12) "ص" else "م"
        val h12 = when {
            hh % 24 == 0  -> 12
            hh % 24 <= 12 -> hh % 24
            else           -> hh % 24 - 12
        }
        return "%d:%02d %s".format(h12, mm, ampm)
    }

    private fun Double.roundToInt() = (this + 0.5).toInt()
}
