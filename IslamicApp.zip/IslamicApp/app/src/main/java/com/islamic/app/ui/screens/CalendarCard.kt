package com.islamic.app.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamic.app.presentation.viewmodel.CalendarUiState
import com.islamic.app.ui.components.GlassCardGreen
import com.islamic.app.ui.theme.*

@Composable
fun CalendarCard(state: CalendarUiState, modifier: Modifier = Modifier) {

    // Ramadan glow animation
    val infiniteTransition = rememberInfiniteTransition(label = "calendar")
    val glowAlpha by infiniteTransition.animateFloat(
        initialValue = 0.2f, targetValue = 0.5f,
        animationSpec = infiniteRepeatable(tween(2500, easing = EaseInOutSine), RepeatMode.Reverse),
        label = "alpha"
    )

    GlassCardGreen(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Moon icon with glow
                Text(
                    text = if (state.isRamadan) "🌙" else if (state.isFriday) "✨" else "📅",
                    fontSize = 22.sp
                )
                Text(
                    text = "تقويم أم القرى",
                    color = IslamicGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium,
                    letterSpacing = 0.5.sp
                )
            }

            Spacer(Modifier.height(20.dp))

            // Day name
            Text(
                text = state.dayName,
                color = Color.White.copy(alpha = 0.7f),
                fontSize = 14.sp,
                letterSpacing = 2.sp
            )

            Spacer(Modifier.height(8.dp))

            // Big Hijri day number
            Text(
                text = state.hijriDay,
                color = Color.White,
                fontSize = 80.sp,
                fontWeight = FontWeight.Bold,
                lineHeight = 80.sp
            )

            // Hijri month - gold colored
            Text(
                text = state.hijriMonth,
                color = IslamicGold,
                fontSize = 24.sp,
                fontWeight = FontWeight.SemiBold
            )

            // Hijri year
            Text(
                text = state.hijriYear,
                color = Color.White.copy(alpha = 0.8f),
                fontSize = 16.sp
            )

            // Divider
            Spacer(Modifier.height(16.dp))
            Box(
                modifier = Modifier
                    .width(80.dp)
                    .height(1.dp)
                    .background(
                        Brush.horizontalGradient(
                            listOf(Color.Transparent, IslamicGold, Color.Transparent)
                        )
                    )
            )
            Spacer(Modifier.height(16.dp))

            // Gregorian date
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = "${state.gregorianDate} ${state.gregorianMonth}",
                    color = Color.White.copy(alpha = 0.65f),
                    fontSize = 14.sp,
                    textAlign = TextAlign.Center
                )
            }

            // Occasion badge
            AnimatedVisibility(visible = state.occasion != null) {
                state.occasion?.let { occ ->
                    Spacer(Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = IslamicGold.copy(alpha = 0.2f),
                        tonalElevation = 0.dp
                    ) {
                        Text(
                            text = occ,
                            color = IslamicGoldLight,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp),
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        }
    }
}
