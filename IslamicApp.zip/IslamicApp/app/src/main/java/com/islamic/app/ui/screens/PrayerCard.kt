package com.islamic.app.ui.screens

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamic.app.domain.model.PrayerTimes
import com.islamic.app.presentation.viewmodel.PrayerUiState
import com.islamic.app.ui.components.GlassCardGold
import com.islamic.app.ui.theme.*

@Composable
fun PrayerCard(state: PrayerUiState, modifier: Modifier = Modifier) {
    GlassCardGold(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("🕌", fontSize = 22.sp)
                Text(
                    "أوقات الصلاة",
                    color = IslamicGold,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            if (state.isLoading) {
                Spacer(Modifier.height(32.dp))
                CircularProgressIndicator(
                    color = IslamicGold,
                    modifier = Modifier.align(Alignment.CenterHorizontally)
                )
                Spacer(Modifier.height(32.dp))
            } else {
                state.times?.let { prayers ->
                    // Next prayer highlight
                    Spacer(Modifier.height(16.dp))
                    NextPrayerBanner(
                        name = prayers.nextPrayer,
                        time = prayers.nextPrayerTime,
                        minutes = prayers.minutesToNext
                    )
                    Spacer(Modifier.height(16.dp))

                    // Prayer times list
                    val prayerList = listOf(
                        "الفجر"   to prayers.fajr,
                        "الشروق"  to prayers.sunrise,
                        "الظهر"   to prayers.dhuhr,
                        "العصر"   to prayers.asr,
                        "المغرب"  to prayers.maghrib,
                        "العشاء"  to prayers.isha
                    )
                    prayerList.forEachIndexed { index, (name, time) ->
                        PrayerRow(
                            name = name,
                            time = time,
                            isNext = name == prayers.nextPrayer,
                            isSunrise = name == "الشروق"
                        )
                        if (index < prayerList.size - 1) {
                            Divider(
                                color = Color.White.copy(alpha = 0.07f),
                                thickness = 0.5.dp
                            )
                        }
                    }

                    // Location
                    Spacer(Modifier.height(12.dp))
                    Text(
                        text = "📍 ${state.locationName}",
                        color = Color.White.copy(alpha = 0.4f),
                        fontSize = 11.sp,
                        modifier = Modifier.fillMaxWidth(),
                        textAlign = TextAlign.End
                    )
                }
            }
        }
    }
}

@Composable
private fun NextPrayerBanner(name: String, time: String, minutes: Int) {
    val infiniteTransition = rememberInfiniteTransition(label = "next")
    val alpha by infiniteTransition.animateFloat(
        initialValue = 0.3f, targetValue = 0.6f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "bannerAlpha"
    )
    Surface(
        shape = RoundedCornerShape(16.dp),
        color = IslamicGold.copy(alpha = alpha),
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("الصلاة القادمة", color = IslamicGoldLight, fontSize = 11.sp)
                Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(time, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text(
                    text = "بعد ${minutes} دقيقة",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 11.sp
                )
            }
        }
    }
}

@Composable
private fun PrayerRow(name: String, time: String, isNext: Boolean, isSunrise: Boolean) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 10.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        val nameColor = when {
            isNext    -> IslamicGoldLight
            isSunrise -> Color.White.copy(alpha = 0.45f)
            else      -> Color.White.copy(alpha = 0.85f)
        }
        val timeColor = when {
            isNext    -> IslamicGold
            isSunrise -> Color.White.copy(alpha = 0.4f)
            else      -> Color.White.copy(alpha = 0.75f)
        }
        Text(
            text = time,
            color = timeColor,
            fontSize = if (isNext) 17.sp else 15.sp,
            fontWeight = if (isNext) FontWeight.Bold else FontWeight.Normal
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            if (isNext) {
                Surface(
                    shape = RoundedCornerShape(50),
                    color = IslamicGold.copy(alpha = 0.2f)
                ) {
                    Text("●", color = IslamicGold, fontSize = 8.sp,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                }
                Spacer(Modifier.width(6.dp))
            }
            Text(
                text = name,
                color = nameColor,
                fontSize = if (isNext) 17.sp else 15.sp,
                fontWeight = if (isNext) FontWeight.SemiBold else FontWeight.Normal
            )
        }
    }
}
