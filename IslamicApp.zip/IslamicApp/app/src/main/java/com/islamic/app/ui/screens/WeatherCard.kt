package com.islamic.app.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.islamic.app.data.api.ForecastDay
import com.islamic.app.data.api.WeatherUiState
import com.islamic.app.ui.components.GlassCardBlue
import com.islamic.app.ui.components.GlassCard
import com.islamic.app.ui.theme.*

@Composable
fun WeatherCard(state: WeatherUiState, modifier: Modifier = Modifier) {
    var expanded by remember { mutableStateOf(false) }

    GlassCardBlue(modifier = modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(24.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.clickable { expanded = !expanded }
                ) {
                    Icon(
                        if (expanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                        contentDescription = null,
                        tint = Color.White.copy(alpha = 0.6f),
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(Modifier.width(4.dp))
                    Text(
                        if (expanded) "إخفاء التفاصيل" else "التوقعات",
                        color = Color.White.copy(alpha = 0.5f),
                        fontSize = 12.sp
                    )
                }
                Text(
                    "الطقس الآن",
                    color = Color(0xFF4FC3F7),
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Medium
                )
            }

            when {
                state.isLoading -> {
                    Spacer(Modifier.height(32.dp))
                    CircularProgressIndicator(
                        color = Color(0xFF4FC3F7),
                        modifier = Modifier.align(Alignment.CenterHorizontally)
                    )
                    Spacer(Modifier.height(32.dp))
                }
                state.error != null -> {
                    Spacer(Modifier.height(20.dp))
                    Text(
                        text = state.error,
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 13.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "اذهب إلى openweathermap.org\nللحصول على مفتاح API مجاني",
                        color = Color(0xFF4FC3F7).copy(alpha = 0.7f),
                        fontSize = 11.sp,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(20.dp))
                }
                else -> {
                    Spacer(Modifier.height(16.dp))

                    // Main weather display
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Temp + city
                        Column {
                            Text(
                                text = "${state.temperature}°",
                                color = Color.White,
                                fontSize = 72.sp,
                                fontWeight = FontWeight.Thin,
                                lineHeight = 72.sp
                            )
                            Text(
                                text = state.conditionAr,
                                color = Color(0xFF4FC3F7),
                                fontSize = 16.sp
                            )
                            Text(
                                text = "📍 ${state.cityName}",
                                color = Color.White.copy(alpha = 0.55f),
                                fontSize = 12.sp
                            )
                        }

                        // Weather icon + feels like
                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = state.weatherIcon, fontSize = 56.sp)
                            Spacer(Modifier.height(4.dp))
                            Text(
                                text = "يُحسّ بـ ${state.feelsLike}°",
                                color = Color.White.copy(alpha = 0.6f),
                                fontSize = 12.sp
                            )
                        }
                    }

                    Spacer(Modifier.height(16.dp))

                    // Stats row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        WeatherStat("💧", "${state.humidity}%", "الرطوبة")
                        WeatherStat("💨", "${state.windSpeed.toInt()} م/ث", "الرياح")
                    }

                    // Expandable 5-day forecast
                    AnimatedVisibility(
                        visible = expanded,
                        enter = expandVertically() + fadeIn(),
                        exit = shrinkVertically() + fadeOut()
                    ) {
                        Column {
                            Spacer(Modifier.height(16.dp))
                            Divider(color = Color.White.copy(alpha = 0.1f))
                            Spacer(Modifier.height(12.dp))
                            Text(
                                "توقعات ٥ أيام",
                                color = Color.White.copy(alpha = 0.7f),
                                fontSize = 13.sp,
                                modifier = Modifier.fillMaxWidth(),
                                textAlign = TextAlign.End,
                                fontWeight = FontWeight.Medium
                            )
                            Spacer(Modifier.height(10.dp))
                            if (state.forecast.isEmpty()) {
                                Text(
                                    "لا تتوفر بيانات التوقعات",
                                    color = Color.White.copy(alpha = 0.4f),
                                    fontSize = 12.sp,
                                    modifier = Modifier.fillMaxWidth(),
                                    textAlign = TextAlign.Center
                                )
                            } else {
                                state.forecast.forEach { day ->
                                    ForecastRow(day)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WeatherStat(icon: String, value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 18.sp)
        Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        Text(label, color = Color.White.copy(alpha = 0.5f), fontSize = 11.sp)
    }
}

@Composable
private fun ForecastRow(day: ForecastDay) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "${day.minTemp}° / ${day.maxTemp}°",
            color = Color.White.copy(alpha = 0.75f),
            fontSize = 14.sp
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(day.icon, fontSize = 16.sp)
            Spacer(Modifier.width(8.dp))
            Text(
                day.condition,
                color = Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp
            )
        }
        Text(
            day.day,
            color = Color.White,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
