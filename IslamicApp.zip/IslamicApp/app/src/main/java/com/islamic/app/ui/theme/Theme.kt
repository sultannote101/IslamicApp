package com.islamic.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color

// === Islamic Color Palette ===
val IslamicGreen       = Color(0xFF1B5E20)
val IslamicGreenLight  = Color(0xFF2E7D32)
val IslamicGold        = Color(0xFFD4AF37)
val IslamicGoldLight   = Color(0xFFFFD700)
val NightBlue          = Color(0xFF0D1B2A)
val DeepNavy           = Color(0xFF0A0F1E)
val MidnightPurple     = Color(0xFF1A0533)
val StarWhite          = Color(0xFFF8F8FF)

// Glass colors
val GlassWhite         = Color(0x22FFFFFF)
val GlassBorder        = Color(0x44FFFFFF)
val GlassGreen         = Color(0x331B5E20)
val GlassGold          = Color(0x33D4AF37)

// Gradients
val BackgroundGradient = Brush.verticalGradient(
    colors = listOf(
        Color(0xFF0A1628),
        Color(0xFF0D2137),
        Color(0xFF1A2744),
    )
)

val GreenGlowGradient = Brush.radialGradient(
    colors = listOf(
        Color(0x441B5E20),
        Color(0x001B5E20),
    )
)

val GoldGlowGradient = Brush.radialGradient(
    colors = listOf(
        Color(0x33D4AF37),
        Color(0x00D4AF37),
    )
)

val GlassCardGradient = Brush.linearGradient(
    colors = listOf(
        Color(0x33FFFFFF),
        Color(0x11FFFFFF),
    )
)

val GoldAccentGradient = Brush.linearGradient(
    colors = listOf(
        Color(0xFFD4AF37),
        Color(0xFFF5CC52),
        Color(0xFFD4AF37),
    )
)

private val DarkColorScheme = darkColorScheme(
    primary          = IslamicGold,
    onPrimary        = DeepNavy,
    secondary        = IslamicGreenLight,
    onSecondary      = StarWhite,
    background       = DeepNavy,
    onBackground     = StarWhite,
    surface          = Color(0xFF0D1B2A),
    onSurface        = StarWhite,
    surfaceVariant   = Color(0x22FFFFFF),
    onSurfaceVariant = Color(0xAAFFFFFF),
)

@Composable
fun IslamicAppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
